package com.example.k2025_02_15_viewmodel.model

enum class QuestionType {
    ARITHMETIC,
    SPACE,
    QUANTUM
}

data class BooleanQuestion(val id: Int, val text: String, val spanishText: String, val isTrue: Boolean, val questionType: QuestionType)

val booleanQuestionsList = listOf<BooleanQuestion> (
    BooleanQuestion(1,"2+2 = 7", "2+2 = 7", false, QuestionType.ARITHMETIC),
    BooleanQuestion(2, "Pluto is a planet", "Plutón es un planeta", false,QuestionType.SPACE),
    BooleanQuestion(3,"Saturn has only two moons","Saturno tiene sólo dos lunas.", false, QuestionType.SPACE),
    BooleanQuestion(4,"Saturn has at least 146 moons", "Saturno tiene al menos 146 lunas.",true, QuestionType.SPACE),
    BooleanQuestion(5,"Saturn has rings", "Saturno tiene anillos.",true, QuestionType.SPACE),
    BooleanQuestion(6,"Saturn is the largest planet", "Saturno es el planeta más grande.", false,QuestionType.SPACE),
    BooleanQuestion(7,"Jupiter is the largest planet", "Júpiter es el planeta más grande.", true, QuestionType.SPACE),
    BooleanQuestion(8,"The earth is the third planet from the sun", "La tierra es el tercer planeta desde el sol." , true, QuestionType.SPACE),
    BooleanQuestion(9,"The earth is between venus and mars", "La tierra está entre venus y marte.", true, QuestionType.SPACE),
    BooleanQuestion(10,"The closest planet to the sun is mercury", "El planeta más cercano al sol es mercurio.",true, QuestionType.SPACE),
)
