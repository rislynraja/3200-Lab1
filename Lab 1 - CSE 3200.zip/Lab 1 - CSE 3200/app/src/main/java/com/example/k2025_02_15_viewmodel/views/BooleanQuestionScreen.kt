package com.example.k2025_02_15_viewmodel.views

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.example.k2025_02_15_viewmodel.views.Score
import com.example.k2025_02_15_viewmodel.model.booleanQuestionsList
import com.example.k2025_02_15_viewmodel.views.ui.theme.BooleanQuestionsAppTheme

@Composable
fun BooleanQuestionScreen() {
    var useranswers = remember { mutableStateOf(BooleanArray(booleanQuestionsList.size))}
    val context = LocalContext.current

    var isSpanish by remember { mutableStateOf(false)}

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        Button(
            onClick = {
                isSpanish = !isSpanish
            },
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            Text(text = "Switch to ${if (isSpanish) "English" else "Spanish"}")
        }
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(booleanQuestionsList) { currentQuestion ->
                val questioni = booleanQuestionsList.indexOf(currentQuestion)

                Text(
                    text = if (isSpanish) currentQuestion.spanishText else currentQuestion.text,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row {
                    Button(
                        onClick = {
                            useranswers.value[questioni] = true
                        },
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(text = "True")
                    }

                    Button(
                        onClick = {
                            useranswers.value[questioni] = false
                        }
                    ) {
                        Text(text = "False")
                    }
                }
            }

        }

        Button(
            onClick = {
                val score = calcScore(useranswers.value)

                val intent = Intent(context, Score::class.java).apply {
                    putExtra("Score", score)
                }
                context.startActivity(intent)
            }
        ) {
            Text(text = "Done")
        }

    }


}

fun calcScore(answers: BooleanArray): Int {
    var score = 0
    for (i in answers.indices ) {
        if (answers[i] == booleanQuestionsList[i].isTrue) {
            score++
        }
    }
    return score
}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    BooleanQuestionsAppTheme {
        BooleanQuestionScreen()
    }


}