package com.example.k2025_02_15_viewmodel.views

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class BooleanQuestionViewModel() : ViewModel() {
    val myState = mutableStateOf("")
}