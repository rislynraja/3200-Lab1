package com.example.k2025_02_15_viewmodel.views

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

class Score : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val score = intent.getIntExtra("Score", 0)
        setContent {
            ScoreScreen(score)
        }
    }
}

@Composable
fun ScoreScreen(score: Int) {
    val context = LocalContext.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        Text(
            text = "Final Score: $score",
            fontSize = 32.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )
    }


}

@Preview(showBackground = true)
@Composable
fun TempScore(){
    ScoreScreen(score = 10)
}
